<template>
  <div>
	这是使用全局注册的基础组件
  </div>
</template>


<script>
  export default {

  }
</script>

<style scoped>

</style>